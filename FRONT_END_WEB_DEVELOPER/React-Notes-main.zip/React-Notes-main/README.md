# React-Notes
"Notes" is a simple note-taking app built with React.js, MongoDB, Node.js, Express, and Bootstrap.
Check out the app:
https://glacial-harbor-79756.herokuapp.com/
